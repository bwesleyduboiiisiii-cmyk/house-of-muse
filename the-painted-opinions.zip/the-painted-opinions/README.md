# The Painted Opinions — website

Static single-page site for the podcast *The Painted Opinions*, hosted by Alicia.
No build step, no framework. Just open `index.html` to preview locally, or deploy the folder.

```
the-painted-opinions/
├── index.html        ← the whole site
├── vercel.json       ← deploy config (caching + clean URLs)
├── assets/
│   ├── logo.webp / logo.jpg
│   ├── poster.webp / poster.jpg
│   └── og-cover.jpg  ← 1200×630 social share card
└── README.md
```

---

## 1. Edit everything in one place

Open `index.html` and find the **`CONFIG`** block near the bottom (inside `<script>`).
Everything you'll want to change lives there:

| What | Where in CONFIG | Notes |
|------|-----------------|-------|
| Listen-on links (Spotify, Apple, etc.) | `platforms[].url` | Replace each `"#"` with the real show URL |
| Social buttons | `socials[].url` | TikTok / Instagram / YouTube |
| Episodes (title, blurb, length, audio) | `episodes[]` | Newest first. Swap the demo MP3s for your real files |
| Clip of the week | `clip.youtubeId` | Paste a YouTube/Short video ID to enable the embed |
| "Follow on TikTok" button | `tiktokUrl` | |
| Email signup destination | `formEndpoint` | See section 3 |
| Analytics | `analytics.plausibleDomain` / `analytics.gaId` | See section 5 |

The episode list, platform grid, and social buttons all **render from CONFIG** — add an
episode by adding one entry to the array, no HTML editing.

> The demo ships with sample MP3s (SoundHelix) so the player actually plays. Replace the
> `audio` URLs with your hosted episode files.

---

## 2. Audio player

A persistent player docks to the bottom the first time someone hits **Play**.
Click an episode's *Play*, the hero's *Play latest episode*, or the player's own button.
It supports play/pause, scrub-to-seek, and auto-advances to the next episode.

---

## 3. Real email signups

The form runs in **demo mode** until you give it an endpoint.

1. Make a free form at [formspree.io](https://formspree.io) (or use Mailchimp/Beehiiv/ConvertKit).
2. Copy the endpoint, e.g. `https://formspree.io/f/abcmyz12`.
3. Paste it into `CONFIG.formEndpoint`.

Submissions POST as JSON `{ "email": "..." }`.

---

## 4. Social share cards

`assets/og-cover.jpg` (1200×630) is wired into the Open Graph / Twitter tags in `<head>`,
so links unfurl with the branded card on TikTok, iMessage, X, etc.

**After you pick a domain, update the URLs in `<head>`** — replace every
`https://thepaintedopinions.com/` with your real domain (the `canonical`, `og:url`,
`og:image`, `twitter:image`, and the RSS/JSON-LD links). Test with
[opengraph.xyz](https://www.opengraph.xyz).

---

## 5. Analytics (optional)

Nothing loads until you fill these in:

- **Plausible** (privacy-friendly): set `analytics.plausibleDomain` to your domain.
- **Google Analytics 4**: set `analytics.gaId` to your `G-XXXXXXXX` ID.

---

## 6. Deploy to Vercel (same flow as your other projects)

**Option A — GitHub (recommended):**
1. `git init && git add . && git commit -m "Painted Opinions site"`
2. Create a repo on GitHub and push.
3. On [vercel.com](https://vercel.com) → **Add New → Project** → import the repo.
4. Framework preset: **Other**. Root directory: the project folder. **Deploy.**

**Option B — drag & drop:** [vercel.com/new](https://vercel.com/new) → drop this folder.

**Custom domain:** Vercel → Project → **Settings → Domains** → add `thepaintedopinions.com`
and point your registrar's records as Vercel instructs. Then update the `<head>` URLs (section 4).

---

## 7. Put the show on Apple / Spotify

The site links a feed at `/feed.xml`. Host your audio with a podcast host
(Spotify for Creators, Buzzsprout, Transistor…) — they generate the real RSS feed that
gets you listed on Apple Podcasts, Spotify, and Amazon. Point `CONFIG.platforms` and the
`<head>` feed link at those URLs once you have them.
